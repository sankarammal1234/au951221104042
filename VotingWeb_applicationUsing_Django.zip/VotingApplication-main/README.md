voting web application using django framework by Sankarammal
